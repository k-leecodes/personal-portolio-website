# Portfolio Website

A Pen created on CodePen.io. Original URL: [https://codepen.io/k-leecodes/pen/PoBqvNe](https://codepen.io/k-leecodes/pen/PoBqvNe).

A single page scrolling portfolio site I was working on using fullpage.js, wow.js and animate.css.